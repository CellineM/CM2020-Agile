/** @type {import('tailwindcss').Config} */

module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', // all the javascript files in src and typeScript(if there are one)
],
  theme: {
    colors:{ 'purple': "#676f9d",
             'white': "rgb(255 255 255)",
             'black': "rgb(0,0,0)",
             'orange':"rgb(255,191,71)",
             'dpurple': "rgb(66,71,105)",
             
  },
  
  fontFamily: {
    "Cantarell": ['cantarell', 'sans-serif']

  },
  

    extend: {
      

    },
  },
  plugins: [],
}

