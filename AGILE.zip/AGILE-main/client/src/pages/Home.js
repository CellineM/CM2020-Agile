import React from 'react';
import Fact from '../assets/howItWorks.png';
import { useMediaQuery } from 'react-responsive';

function Home() {
  
  return (
    <div className={`home bg-dpurple min-h-screen overflow-x-auto`}>

      <div className='flex flex-row justify-between'>
        <div className='aboutUs w-1/2 p-4 text-white'>
          <h2 className="font-bold">About Us</h2>
          <br/>
          <p>We are currently students at the University of London, and this website is created for our project focusing on Fake News Detection.</p>
          <p>Our mission for this project is to stop the spread of false and misleading information.
            To make sure you only get the most accurate and trustworthy information, we want to offer a
            comprehensive platform for locating and authenticating news stories. Every facet of our work
            is driven by our dedication to truth because we firmly think that an informed society is a resilient society.
          </p>
        </div>

        <div className='w-1/2 p-4'>
          <div className='whatIsFactify text-white'>
            <h2 className="font-bold">What is Factify?</h2>
            <br/>
            <p>Factify is a fake news detection website where our goal is to guide you in search of the truth. It's harder
              than ever to separate fake news from real news in a time when information and news are readily available everywhere.
              Factify is here to break through the clutter and provide you with the resources you need to responsibly traverse the 
              digital world.
            </p>
          </div>
        </div>
      </div>

      <hr className='lineBorder'/> 
      <hr className='lineBorder2'/>

      <h2 className="text-white font-bold p-4">How It Works</h2>

      <div className='flex items-center'>
        <div className='picture p-4 w-1/2'>
          <img src={Fact} alt="How It Works" className="w-3/4 h-auto" />
        </div>

        <div className='howItWorks1 p-6 text-white w-1/2'>
          <p>Once the user submits a text or image to detect fake news, real-time fact-checking is done by using a combination of 
            automated tools such as AI(Artificial Intelligence) and NLP(Natural Language Processing) to name a couple. The tools
            would then do a fake news detection by analyzing the text by identifying the patterns as well as verifying the text for
            accuracy, using metadata for image analysis, and analyzing the social interaction and the cues. Additionally, it uses an 
            algorithm for fake news detection. It detects any spread of patterns or identifies false information. Finally it will 
            swiftly and precisely return the output as true or false, or multiclass classification output such as hoax, bias, true-fact, etc.
          </p>
        </div>
      </div>

    </div>
  );
}

export default Home;
