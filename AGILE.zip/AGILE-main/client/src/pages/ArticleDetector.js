import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../design/tailwind.css';

const ArticleDetector = () => {
  // const [textInput, configureInput] = useState("");
  // const [chosenFile, setChosenFile] = useState(null);
  // const [fileName, setFileName] = useState(""); // Added state for file name
  // const navigate = useNavigate();

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   const data = {
  //     textInput,
  //     fileName
  //   }
  //   try {
  //     const response = await axios.post('http://localhost:4000/submitArticle', data, {
  //       headers: {
  //         'Content-Type': 'application/json'
  //       }
  //     });
  //     console.log('Response:', response.data);
  //     // Handle response data as needed
  //   } catch (error) {
  //     console.error('Error submitting article:', error);
  //   }
  // };

  // const manageInput = (event) => {
  //   configureInput(event.target.value);
  // };

  // const handleFileChange = (event) => {
  //   const file = event.target.files[0];
    // Use compressorjs to compress the image
    // new Compressor(file, {
    //   quality: 0.6, // Adjust quality (0.1 - 1.0)
    //   maxWidth: 32, // Maximum width of the output image
    //   maxHeight: 32, // Maximum height of the output image
    //   mimeType: 'image/jpeg', // Output image format
    //   success(result) {
    //     // Convert the compressed image to a data URL
    //     const reader = new FileReader();
    //     reader.onload = function(event) {
    //       const compressedFileContent = event.target.result;
    //       setChosenFile(compressedFileContent);
    //     };
    //     reader.readAsDataURL(result); // Read the compressed image as a data URL
    //   },
    //   error(err) {
    //     console.error('Compression failed:', err.message);
    //   },
    // });
  //   console.log(file)
  //   setChosenFile(file);
  //   // Set the file name to display
  //   setFileName(file ? file.name : "");
  // };

  return (
    <div className={'detector bg-dpurple text-white min-h-screen overflow-x-hidden'}>
      <label htmlFor="textIn"><h4 className="text-3xl bg-dpurple font-bold mb-4">Article Detector</h4></label>

      <form id="uploadForm" method='post' action='http://localhost:4000/submitArticle' encType="multipart/form-data">
        {/* <input type="text" name="textInput" placeholder="Enter text" className='bg-purple text-white px-4 py-10 rounded-md mb-4 w-full lg:w-96' id="textIn"></input> */}
        
        <textarea name="textInput" 
        placeholder="Enter text" 
        className='bg-purple text-white px-2 py-3 rounded-md mb-4 w-full lg:w-2/3 h-32 resize-y'>
        </textarea>

        <div className = 'buttons'>
        <input type="file" name="file"/>
        <button type="submit">Upload</button>
        </div>
      </form> 
    </div>
    
  );
};

export default ArticleDetector;
