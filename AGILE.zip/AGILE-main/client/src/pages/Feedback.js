import React, { useState } from 'react';
import axios from 'axios';



const FeedbackForm = () => {
  const [feedbackText, setFeedbackText] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState(null);

  const handleSubmit = async () => {
    try {     
      await axios.post('http://localhost:4000/submitFeedback', { feedbackText });
      alert('Feedback submitted successfully!');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Please submit an article for analysis before submitting feedback');
    }
  };

  return (
    <div className={'feedbackArea bg-dpurple min-h-screen overflow-x-hidden'}>
      <div>
        <label htmlFor="textIn">
          <h4 className="text-xl md:text-2xl lg:text-3xl bg-dpurple text-white mb-4 font-bold">
            Feedback
          </h4>
        </label>
        <textarea
          className="bg-purple text-white rounded resize-y w-full lg:w-3/5 mb-3"
          id='textIn' 
          value={feedbackText} 
          onChange={(e) => setFeedbackText(e.target.value)}
          rows='10'
        ></textarea>
      </div>

      <button className="bg-purple rounded text-white py-1 px-3 lg:ml-4 lg:w-1/4 xl:w-1/4"
        onClick={handleSubmit}>
        Submit Feedback
      </button>


      {/* Display submission status */}
      {submissionStatus && (
        <div className={`submissionStatus ${submissionStatus} mt-4 text-base md:text-lg lg:text-xl text-white`}>
          {submissionStatus === 'success' && 'Feedback submitted successfully!'}
          {submissionStatus === 'failure' && 'Failed to submit feedback.'}
          {submissionStatus === 'error' && 'Error occurred while submitting feedback.'}
        </div>
      )}
    </div>
  );
};

export default FeedbackForm;
