import React, { useState } from 'react';
import '../design/tailwind.css';

const Faq = () => {
  const faqData = [
    {
      question: '1. Can I use Factify for free?',
      answer: 'Indeed, Factify is a public service that can be used for free. Our goal is to aid in the battle against false information by offering a user-friendly and easily accessible platform.',
    },
    {
      question: '2. Can my submissions for verification include both text and photos?',
      answer: 'Sure, you can submit images and text to Factify for the purpose of detecting bogus news. All you have to do is type in the text or upload the image you would like to verify, and our tools will do the content analysis.',
    },
    {
      question: '3. What kinds of results can Factify offer?',
      answer: 'Factify produces a variety of results, including multiclass classifications like bias, true-fact, hoax, and more, in addition to true or false conclusions. The purpose of the results is to assist users in comprehending the type of material they come across.',
    },
    {
      question: '4. Does Factify support any particular social or political agenda?',
      answer: 'No. Factify is an independent platform that is not associated with any social or political entity. Our only goals are to disseminate correct knowledge and prevent false information.',
    },
    {
      question: '5. To what extent does Factify identify bogus news?',
      answer: 'Although there is no such thing as a flawless tool, Factify uses cutting-edge algorithms and technology to aim for accuracy. Our technology is always changing in order to maintain accuracy and keep up with the latest developments in the misinformation industry.',
    },
  ];

  const [activeBoxes, setActiveBoxes] = useState(null);

  const handleToggle = (boxes) => {
    setActiveBoxes(activeBoxes === boxes ? null : boxes);
  };

  return (
    <div className='faqArea bg-dpurple text-white px-10 min-h-screen overflow-x-auto'>
      <h1>Frequently Asked Questions (FAQ)</h1>

      {faqData.map((qns, boxes) => (
        <div
          key={boxes}
          className='faqQuestions border rounded p-4 mb-6 cursor-pointer'
          onClick={() => handleToggle(boxes)}
        >
          <h2>{qns.question}</h2>
          {activeBoxes === boxes && <p>{qns.answer}</p>}
        </div>
      ))}
    </div>
  );
};

export default Faq;
