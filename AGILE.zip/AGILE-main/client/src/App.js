import './App.css';
import Navbar from './Components/Navbar';
import Footer from './Components/Footer';
import Home from './pages/Home';
import ArticleDetector from './pages/ArticleDetector';
import Analysis from './Analysis';
import Faq from './pages/Faq';
import Feedback from './pages/Feedback';
import React, { useEffect } from 'react';
import axios from 'axios';



// calling Browser Router as router 
// Switch = Routes, Switch only used for react-router-dom@5 or below
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';



function App() {



  return (
  


    <div className="App flex flex-col min-h-screen">
      <Router>
        <Navbar/>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/ArticleDetector" element={<ArticleDetector/>}/>
          <Route path="/Analysis" element={<Analysis />} />
          <Route path="/Faq" element={<Faq/>}/>
          <Route path="/Feedback" element={<Feedback/>}/>
        </Routes>
        <Footer />
      </Router>

    </div>
  );
}

export default App;
