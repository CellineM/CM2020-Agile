from flask import Flask, request, redirect, jsonify, url_for, render_template
from flask_cors import CORS
from werkzeug.utils import secure_filename
from supabase_py import create_client, Client
from transformers import RobertaForSequenceClassification, RobertaTokenizer
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
from PIL import Image
import os

# Get the connection details from environment variables
SUPABASE_URL = "https://austllmbcytfaoilxfcg.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF1c3RsbG1iY3l0ZmFvaWx4ZmNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDgwODYwNDAsImV4cCI6MjAyMzY2MjA0MH0.4RDf8qAhJimbkT2NS5RNjguqIk-TKZp8fA4qywx7NOw"

# Create a Supabase client
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

UPLOAD_DIRECTORY = '../images/'

app = Flask(__name__)
CORS(app)

global global_inserted_uid
global_inserted_uid = None


@app.route('/submitArticle', methods=['POST'])
def submit_article():
    try:
        # Access the form data passed as 'data'
        # data = request.json
        # print(data)
        # Extract text input and chosen file from the 'data' dictionary
        global global_inserted_uid
        if global_inserted_uid:
            # If a global user ID already exists, use it
            inserted_uid = global_inserted_uid
            print("Using existing user ID:", inserted_uid)
        else:
            # Insert a new user into the user table
            response = supabase.table('User').insert({}).execute()
            if response['status_code'] == 201:
                # Retrieve the inserted user ID
                inserted_data = response['data']
                inserted_uid = inserted_data[0]['id']
                global_inserted_uid = inserted_uid  # Store the user ID globally
                print("New user created with ID:", inserted_uid)
            else:
                # Handle error
                error_message = response.get('error', 'Unknown error')
                return jsonify({'error': f'Failed to create user: {error_message}'}), 500
    
        text_input = request.form['textInput']
        chosen_file = request.files['file']
        print(text_input)
        print(chosen_file.filename)

        if chosen_file.filename == '':
            img_file = ""
        else:
            # Save the uploaded file to a location or process it as needed
            filename = secure_filename(chosen_file.filename)
            chosen_file.save('../images/' + filename)
            img_file = filename

        # Insert the article input data into the 'Analysis' table using Supabase
        response_builder = supabase.table('Analysis').insert({
            'textFile': text_input,
            'imgFile': img_file,
            'userId': global_inserted_uid 
        })

        # Execute the request
        response = response_builder.execute()
        print("Response type:", type(response))
        print("Response:", response)        # Check if the response indicates success
        if response:
            # Article input creation successful
            inserted_item = response['data']
            # Get the ID, text, image of the inserted item
            inserted_id = inserted_item[0]['id']

            print("Inserted item ID:", inserted_id)
            return redirect(url_for('analysis', id=inserted_id))
        else:
            # Handle error
            print('Error submitting article:', response)
            return jsonify({'error': 'Internal Server Error 1'}), 500

    except Exception as e:
        print('Error submitting article:', str(e))
        return jsonify({'error': 'Internal Server Error 2'}), 500

# Load the pre-trained RoBERTa model
tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
text_model = RobertaForSequenceClassification.from_pretrained('roberta-base')
# Load fine-tuned weights
text_model.load_state_dict(torch.load('../models/RoBERTa.pth', map_location=torch.device('cpu')))

# Load the pretrained ResNet-50 model
resnet50 = models.resnet50(pretrained=True)
# Freeze all layers except the final fully connected layer
for param in resnet50.parameters():
    param.requires_grad = False

# Replace the final fully connected layer (classifier) with a new one
num_features = resnet50.fc.in_features
resnet50.fc = nn.Linear(num_features, 2)
img_model = resnet50

# Load fine-tuned weights
img_model.load_state_dict(torch.load('../models/resnet.pth', map_location=torch.device('cpu')))
img_model.eval()

# Define the image preprocessing pipeline
preprocess = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])


# Define route for analysis
@app.route('/analysis/<int:id>', methods=['GET'])
def analysis(id):
    try:
        # Get input text from the request JSON data
        print(id)
        id = str(id)
        response = supabase.from_('Analysis').select().eq('id', id).execute()
        print(response)
        userInput = response['data'][0]
        input_text = userInput['textFile']
        input_img = userInput['imgFile']
        predicted_class = None  # Initialize predicted_class here
        # Get input text from the URL parameters
        text_input = request.args.get('text_input')
        img_file = request.args.get('img_file')

        # Return the constructed response
        # return jsonify(response_data), 200

        if input_text == '' and input_img == '':
            return redirect('http://localhost:3000/articleDetector')

        if input_text != '':
            # Preprocess the input text
            inputs = tokenizer(input_text, return_tensors='pt', truncation=True, padding=True)

            # Perform analysis using the model
            with torch.no_grad():
                outputs = text_model(**inputs)

            # Process the output as needed
            logits = outputs.logits
            text_probabilities = torch.softmax(logits, dim=1).tolist()[0]

        if input_img != '':
            # Get the image file from the request
            relative_path = '../images/' + input_img

            # Check if the file exists
            if os.path.exists(relative_path):
                image = Image.open(relative_path).convert('RGB')

                input_tensor = preprocess(image).unsqueeze(0)  # Add batch dimension

                # Perform inference
                with torch.no_grad():
                    output = img_model(input_tensor)

                # Postprocess the output
                _, predicted_class = output.max(1)

                print("Image file found:", relative_path)
            else:
                print("Image file not found:", relative_path)
                predicted_class = None  # Set predicted_class to None when image file is not found
        else:
            predicted_class = None  # Set predicted_class to None when there is no image input
            
        if input_text == "":
            text_probabilities = [0.5, 0.5]

        # Store analysis results in the FakeNewsDetector table
        try:
            # Query the Analysis table to get the analysisId
            analysis_id_response = supabase.table('Analysis').select('id').execute()
            if analysis_id_response['status_code'] == 200 and analysis_id_response['data']:
                # Get the analysisId from the response
                analysis_id = analysis_id_response['data'][0]['id']
                if predicted_class is not None:
                    img_result = predicted_class.item()
                else:
                    img_result = None

                # Build the insertion request for FakeNewsDetector table
                Newresponse_builder = supabase.table('FakeNewsDetector').insert({
                    'id': id,
                    'analysisId': analysis_id,  # Use the fetched analysisId
                    'text_result': text_probabilities[1],  # Store both values as a list
                    'img_result': img_result
                })

                # Execute the insertion request
                Newresponse = Newresponse_builder.execute()
                print("Response after insertion:", Newresponse)

                # Redirect to the Analysis page with the analysis ID and result values as query parameters
                redirect_url = f'http://localhost:3000/analysis?id={id}&text_result={text_probabilities[1]}&img_result={img_result}'
                return redirect(redirect_url)

            else:
                print('No analysis ID found or Analysis table is empty')
                return jsonify({'error': 'No analysis ID found or Analysis table is empty'}), 404

        except Exception as e:
            print('Error during inserting data:', str(e))
            return jsonify({'error': 'Internal Server Error'}), 500

    except Exception as e:
        print('Error during analysis:', str(e))
        return jsonify({'error': 'Internal Server Error'}), 500
    
@app.route('/submitFeedback', methods=['POST'])
def submit_feedback():
    
    feedback_text = request.json.get('feedbackText')
    global global_inserted_uid
    if global_inserted_uid is not None:
         feedback_insert = supabase.table('Feedback').insert({
         'feedbackText': feedback_text,
         'userId': global_inserted_uid 
            }).execute()
    
         if feedback_insert['status_code'] == 201:
            return jsonify({'message': 'Feedback submitted successfully'}), 201
         
         else:
            return jsonify({'message': 'Failed to submit feedback!'}), 500
         
    else:
        return jsonify({'message':'User have not tried the detector'}), 500

if __name__ == '__main__':
    port = 4000  # Specify the port number you want to use
    print(f"Server is running on http://localhost:{port}")
    app.run(debug=True, port=port)