/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'], // all the javascript files in src and typeScript(if there are one)
  theme: {
    extend: {
      backgroundColor: {
        'slate-rgb': 'rgb(66, 71, 105)',
        
      },
    },
  },
  plugins: [],
}

