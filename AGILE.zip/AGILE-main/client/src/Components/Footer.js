import React from 'react';
import { Link } from 'react-router-dom';
import '../design/tailwind.css';

function Footer() {
  return (
    <div className="bg-purple text-white viewport-width-100 pt-4"> 
      <div className="container mx-auto flex flex-wrap justify-around">

        <div className='md:w-1/4 mb-4 md:mb-0 sections'>
          <h5 className="text-white text-lg font-semibold mb-4 font-Cantarell">Information</h5>
          <Link to="/faq" className="text-gray-300 hover:text-black font-Cantarell">FAQ</Link>
        </div>

        <div className='md:w-1/4 mb-4 md:mb-0 sections'>
          <h5 className="text-lg font-semibold mb-4 font-Cantarell">Contact Us</h5>
          <p>Email: csuolstudents@gmail.com</p>
        </div>

        <div className='md:w-1/4 sections'>
          <h5 className="text-lg font-semibold mb-4 font-Cantarell">Follow Us</h5>
          <p>Instagram & Facebook<br/>@csuolstudents</p>
        </div>

      </div>
    </div>
  );
}

export default Footer;
