import React from 'react'
import Logo from '../assets/factifyLogo.png'
import {Link, useLocation} from 'react-router-dom'
import '../design/tailwind.css'


function Navbar() {
  const location = useLocation();
  return (
    
    <div className='navbar bg-dpurple  top-0 h-15 flex items-center overflow-x-hidden'>      
        {/* have 2 side one for logo and one for navbar */}
        <div className='logoside '>
            <img src={Logo} alt='Logo' className='md:w-56 -translate-x-7 -translate-y-7'  />
            
        </div>

        {/* navbar */}
        <div className=' flex-1 flex items-center space-x-8 md:space-x-20'>

        <Link
          to='/'
          className={`text-orange 300 text-xl font-normal font-Carme ${
            location.pathname === '/' ? 'border-b-2 border-orange' : ''
          }`}
        >
          Home
        </Link>
            <Link to = "/articleDetector"
            className={`text-orange 300 text-xl font-normal font-Carme ${
              location.pathname === '/articleDetector' ? 'border-b-2 border-orange' : ''
            }`}>
              Detector</Link>


            <Link to = "/feedback"
            className={`text-orange 300 text-xl font-normal font-Carme ${
              location.pathname === '/feedback' ? 'border-b-2 border-orange' : ''
            }`}>
              Feedback</Link>
    
        </div>

    </div>
  )
}

export default Navbar
