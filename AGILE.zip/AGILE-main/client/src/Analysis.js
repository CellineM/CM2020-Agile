import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

const Analysis = () => {
  // Get the URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const [barGraph, setBarGraph] = useState([]);
  const location = useLocation();
  const data = {
    textInput: urlParams.get("text_result"),
    chosenFile: urlParams.get("img_result"),
  };
  // Accessing properties using dot notation
  const textInputValue = data.textInput;
  const chosenFileValue = data.chosenFile;
  console.log('input:' + data)
  useEffect(() => {
    const postData = async () => {
      try {
        console.log(data);
        const response = await axios.post(
          "http://localhost:4000/submitArticle", data
        );
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    postData();
  }, []);

  // // Get the text_result and img_result values from the URL
  const textResult = urlParams.get("text_result");
  const imgResult = urlParams.get("img_result");
  console.log(textResult);
  console.log(imgResult);

  // Dummy data
  const output = [textInputValue, 1 - textInputValue]; // true or false

  // Use dummy data if the server data is not available
  const displayData = barGraph.length > 0 ? barGraph : output;
  // The width for the bar graph
  const barWidth = 150;
  const barHeight = 100;

  return (
    <div className="bg-dpurple text-white min-h-screen flex flex-col items-center overflow-x-hidden">
      <div className='text-3xl font-bold mt-4 mb-20'> 
        <h1>Analysis Results</h1>
      </div>
      

      {/* Bar Graph and Text Result */}
      <div className="analysis-section flex flex-col items-center md:flex-row md:justify-center pl-40">
        {/* Box for Bar Graph */}
        <div className="barGraph-container translate-x-30 mb-4 md:mb-0">
          <svg width={barWidth} height="200">
            {displayData.map((value, index) => (
              <g key={index}>
                {/* bar graph */}
                <rect
                  x={index * (barWidth / displayData.length)} // X-coordinate
                  y={150 - value * barHeight} // Y-coordinate
                  width={(barWidth / displayData.length) - 10} // Width of the bar graph
                  height={value * barHeight} // Height of the bar graph
                  fill="orange" // change the bar color to orange to match the theme
                />
                {/* bar label */}
                <text
                  x={
                    index * (barWidth / displayData.length) +
                    barWidth / displayData.length / 2 -
                    5
                  } // The label
                  y={170} // Y-coordinates
                  textAnchor="middle" // Text align with the bar
                  fill="white" // Text color
                >
                  {index === 0 ? "True" : "False"}
                </text>
              </g>
            ))}
          </svg>
        </div>
        {/* Box for Text Result */}
        <div className="text-container mt-0 md:ml-40"style={{ width: '500px' }}>
         <h2 className='font-bold text-lg'>Result:</h2>
         <br/>
          <p>
          {" "}
            {parseInt(chosenFileValue) === 0
              ? "This image is likely AI generated."
              : parseInt(chosenFileValue) === 1
              ? "This image is likely real."
              : "No image submitted."}
              <br/>...................
          </p>
        </div>
      </div>
    </div>
  );
};

export default Analysis;
